﻿using Microsoft.AspNetCore.Mvc;
using Menu.Models;
using Menu.Data;
using Microsoft.EntityFrameworkCore;

namespace Menu.Controllers
{
    public class Menu : Controller
    {
        private readonly MenuContext _Context;

        public Menu(MenuContext context)
        {
            _Context = context;
        }

        public async Task <IActionResult> Index(string searchString)
        {
            var dishes = from d in _Context.Dishes
                       select d;

            if (!string.IsNullOrEmpty(searchString))
            {
                dishes = dishes.Where(d => d.Name.Contains(searchString));
                return View(await dishes.ToListAsync());
            }

            return View(await dishes.ToListAsync());
        }

        public async Task<IActionResult> Details(int? ID)
        {
            var dish = await _Context.Dishes
                .Include(di => di.DishIngredients)
                .ThenInclude(i => i.Ingredient)
                .FirstOrDefaultAsync(x => x.ID == ID);

            if (dish == null)
            {
                return NotFound();
            }
            return View(dish);

        }
    }
}

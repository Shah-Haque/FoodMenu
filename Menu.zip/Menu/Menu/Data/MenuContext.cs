﻿using Microsoft.EntityFrameworkCore;
using Menu.Models;

namespace Menu.Data
{
    public class MenuContext : DbContext
    {
        public MenuContext(DbContextOptions<MenuContext> Options) 
        : base(Options)
        {  
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<DishIngredientModel>()
            .HasKey(pi => new
            {
                pi.DishID,
                pi.IngredientID
            });

            modelBuilder.Entity<DishIngredientModel>().
            HasOne(d => d.Dish).
            WithMany(di => di.DishIngredients).
            HasForeignKey(d => d.DishID);

            modelBuilder.Entity<DishIngredientModel>().
            HasOne(i => i.Ingredient).
            WithMany(di => di.DishIngredients).
            HasForeignKey(d => d.IngredientID);


            modelBuilder.Entity<DishModel>().HasData(
            new DishModel 
            {
                ID = 1,
                Name = "Cheese pizza",
                Price = 7.99,
                ImageUrl = "https://t4.ftcdn.net/jpg/01/87/40/35/360_F_187403589_B6k32cONE33quq9hX7RAtdpYMBcFU9PV.jpg"
            }
            );

            modelBuilder.Entity<IngredientModel>().HasData(
            new IngredientModel
            {
                 ID = 1,
                 Name = "Tomato Sauce"
            },
            new IngredientModel
            {
                ID = 2,
                Name = "Mozzarella"
            }
            );

            modelBuilder.Entity<DishIngredientModel>().HasData(
            new DishIngredientModel 
            { 
                DishID = 1,
                IngredientID = 1 
            },
            new DishIngredientModel 
            { 
                DishID = 1,
                IngredientID = 2 
            }
            );

            base.OnModelCreating(modelBuilder);
        }

        public DbSet<DishModel> Dishes { get; set; }

        public DbSet<IngredientModel> Ingredients { get; set;}

        public DbSet<DishIngredientModel> DishIngredients { get; set; }

    }
}
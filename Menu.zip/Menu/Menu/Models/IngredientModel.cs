﻿namespace Menu.Models
{
    public class IngredientModel
    {
        public int ID { get; set; }
        public string Name { get; set; }

        public List<DishIngredientModel>? DishIngredients { get; set; }
    }
}

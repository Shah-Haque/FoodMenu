﻿namespace Menu.Models
{
    public class DishIngredientModel
    {
        public int DishID { get; set; }

        public DishModel Dish { get; set; }

        public int IngredientID { get; set; }

        public IngredientModel Ingredient { get; set; }

    }
}
